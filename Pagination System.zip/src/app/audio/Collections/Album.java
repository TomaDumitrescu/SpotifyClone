package app.audio.Collections;

import app.audio.Files.AudioFile;
import app.audio.Files.Song;

import java.util.ArrayList;
import java.util.List;

import fileio.input.SongInput;
import lombok.Getter;

@Getter
public final class Album extends AudioCollection {
    private final String description;
    private final List<Song> songs;
    private final Integer releaseYear;

    /**
     * Instantiates a new Album.
     *
     * @param name the album name
     * @param owner the artist that created it
     * @param songs the list of the songs in the album
     * @param description the description of the album
     * @param releaseYear the date when the album was published
     */
    public Album(final String name, final String owner, final List<SongInput> songs,
                 final String description, final Integer releaseYear) {
        super(name, owner);
        ArrayList<SongInput> songInputs = new ArrayList<>(songs);
        ArrayList<Song> albumSongs = new ArrayList<>();
        for (SongInput songItr: songInputs) {
            Song song = new Song(songItr.getName(), songItr.getDuration(), songItr.getAlbum(),
                    songItr.getTags(), songItr.getLyrics(), songItr.getGenre(),
                    songItr.getReleaseYear(), songItr.getArtist());
            albumSongs.add(song);
        }
        this.songs = albumSongs;
        this.description = description;
        this.releaseYear = releaseYear;
    }

    /**
     * Sums the likes of all songs on this album
     *
     * @return the total likes
     */
    public Integer getLikes() {
        return songs.stream().mapToInt(Song::getLikes).sum();
    }

    @Override
    public boolean matchesName(final String albumName) {
        return this.getName().equalsIgnoreCase(albumName);
    }

    @Override
    public boolean matchesReleaseYear(final String releaseYearFilter) {
        return filterByYear(this.getReleaseYear(), releaseYearFilter);
    }

    @Override
    public boolean matchesOwner(final String user) {
        return this.getOwner().equalsIgnoreCase(user);
    }

    private static boolean filterByYear(final int year, final String query) {
        if (query.startsWith("<")) {
            return year < Integer.parseInt(query.substring(1));
        } else if (query.startsWith(">")) {
            return year > Integer.parseInt(query.substring(1));
        } else {
            return year == Integer.parseInt(query);
        }
    }


    @Override
    public int getNumberOfTracks() {
        return songs.size();
    }

    @Override
    public AudioFile getTrackByIndex(final int index) {
        return songs.get(index);
    }
}
