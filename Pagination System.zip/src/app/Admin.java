package app;

import app.audio.Collections.Album;
import app.audio.Collections.AudioCollection;
import app.audio.Collections.Playlist;
import app.audio.Collections.Podcast;
import app.audio.Files.Episode;
import app.audio.Files.Song;
import app.player.PlayerSource;
import app.user.Artist;
import app.user.Host;
import app.user.User;
import app.utils.Enums;
import fileio.input.EpisodeInput;
import fileio.input.PodcastInput;
import fileio.input.SongInput;
import fileio.input.UserInput;


import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * The type Admin.
 */
public final class Admin {
    private static Admin instance = null;
    private List<User> users = new ArrayList<>();
    private List<Song> songs = new ArrayList<>();
    private List<Podcast> podcasts = new ArrayList<>();
    @Getter
    @Setter
    private List<Album> albums = new ArrayList<>();
    private int timestamp = 0;
    private static final int LIMIT = 5;


    private Admin() {
    }

    /**
     * Lazy singleton initialization for Admin class
     *
     * @return the singleton instance
     */
    public static Admin getInstance() {
        if (instance == null) {
            instance = new Admin();
        }
        return instance;
    }

    /**
     * Sets users.
     *
     * @param userInputList the user input list
     */
    public void setUsers(final List<UserInput> userInputList) {
        users = new ArrayList<>();
        for (UserInput userInput : userInputList) {
            users.add(new User(userInput.getUsername(), userInput.getAge(), userInput.getCity()));
        }
    }

    /**
     * Finds the array list of normal online users.
     *
     * @return the usernames of the online users
     */
    public ArrayList<String> getOnlineUsers() {
        ArrayList<User> allUsers = new ArrayList<>(users);
        ArrayList<String> onlineUsers = new ArrayList<>();

        for (User userItr: allUsers) {
            if (userItr.getType().equals("user")
                    && userItr.getConnection() == Enums.UserActivity.ONLINE) {
                onlineUsers.add(userItr.getUsername());
            }
        }

        return onlineUsers;
    }

    /**
     * Returns a new array list of all users.
     *
     * @return the users list
     */
    public ArrayList<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    /**
     * Adds a user to the system.
     *
     * @return the message of the command validity
     */
    public String addUser(final String username, final int age,
                          final String city, final String type) {
        for (User userItr: users) {
            if (userItr.getUsername().equals(username)) {
                return "The username %s is already taken.".formatted(username);
            }
        }

        switch (type) {
            case "user" -> {
                User newUser = new User(username, age, city);
                newUser.setType(type);
                users.add(newUser);
            }
            case "artist" -> {
                Artist newArtist = new Artist(username, age, city);
                newArtist.setType(type);
                users.add(newArtist);
            }
            case "host" -> {
                Host newHost = new Host(username, age, city);
                newHost.setType(type);
                users.add(newHost);
            }

            default -> {
            }
        }

        return "The username %s has been added successfully.".formatted(username);
    }

    /**
     * Verifies if another user is accessing a playlist of the parameter user.
     *
     * @param normalUser used to get the parameter user products
     * @return true if another user interacts with a playlist of the parameter user
     */
    public boolean anotherUserListensToNormal(final User normalUser) {
        for (User userItr: users) {
            if (userItr.getUsername().equals(normalUser.getUsername())) {
                continue;
            }

            PlayerSource playerSource = userItr.getPlayer().getSource();
            AudioCollection audioCollectionItr = null;

            if (playerSource != null) {
                audioCollectionItr = playerSource.getAudioCollection();
            }

            // if the current player source is not playlist, neglect the next loop
            if (audioCollectionItr == null) {
                continue;
            } else if (audioCollectionItr.getClass() != Playlist.class) {
                continue;
            }

            for (Playlist playlist: normalUser.getPlaylists()) {
                if (playlist.getName().equals(audioCollectionItr.getName())) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Verifies if another user is accessing a product of the current special user.
     *
     * @param specialUser used to get the products and verify if there are in a user player
     * @param userCmp comparing is done one at a time
     * @return true if a normal user listens to the special user products
     */
    public boolean anotherUserListensToSpecial(final User specialUser, final User userCmp) {
        PlayerSource playerSource = userCmp.getPlayer().getSource();
        AudioCollection audioCollection = playerSource.getAudioCollection();

        if (audioCollection != null && audioCollection.getClass() == Album.class
            && specialUser.getType().equals("artist")) {

            Album cmpAlbum = (Album) audioCollection;
            for (Album albumItr: albums) {
                if (!albumItr.getOwner().equals(specialUser.getUsername())) {
                    continue;
                }

                // finding if there are duplicates
                Set<Song> songSet = new HashSet<>(albumItr.getSongs());
                songSet.retainAll(cmpAlbum.getSongs());
                if (!songSet.isEmpty()) {
                    return true;
                }
            }
        } else if (audioCollection != null && audioCollection.getClass() == Playlist.class
                   && specialUser.getType().equals("artist")) {

            Playlist cmpPlaylist = (Playlist) audioCollection;
            if (albums.stream().filter(album ->
                    album.getOwner().equals(specialUser.getUsername())).flatMap(album ->
                    album.getSongs().stream()).anyMatch(song ->
                    cmpPlaylist.getSongs().stream().anyMatch(cmpSong ->
                            song.getName().equals(cmpSong.getName())))) {
                return true;
            }
        } else if (audioCollection != null
                   && audioCollection.getClass() == Podcast.class) {

            Podcast cmpPodcast = (Podcast) audioCollection;
            for (Podcast podcastItr: podcasts) {
                if (!podcastItr.getOwner().equals(specialUser.getUsername())) {
                    continue;
                }

                Set<Episode> episodeSet = new HashSet<>(podcastItr.getEpisodes());
                episodeSet.retainAll(cmpPodcast.getEpisodes());
                if (!episodeSet.isEmpty()) {
                    return true;
                }
            }
        }

        /* no collection loaded, then verify if a song from special user's
         album is listened */
        if (!specialUser.getType().equals("artist")) {
            return false;
        }

        String currentAudioName = "";
        if (userCmp.getPlayer().getCurrentAudioFile() != null) {
            currentAudioName = userCmp.getPlayer().getCurrentAudioFile().getName();
        }

        for (Album albumItr : albums) {
            if (!albumItr.getOwner().equals(specialUser.getUsername())) {
                continue;
            }

            for (Song songItr : albumItr.getSongs()) {
                if (songItr.getName().equals(currentAudioName)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Verifies if a special user cannot be removed from the platform.
     *
     * @return string for validation
     */
    public String validUserDelete(final User specialUser) {
        for (User userItr: users) {
            if (userItr.getUsername().equals(specialUser.getUsername())) {
                continue;
            }

            // case when userItr is on special user's page
            if (userItr.getLastSelectedUser() != null
                && userItr.getLastSelectedUser().getUsername().equals(specialUser.getUsername())) {

                return "%s can't be deleted.".formatted(specialUser.getUsername());
            }

            // case when userItr listens to special user's products
            PlayerSource playerSource = userItr.getPlayer().getSource();
            if (playerSource == null) {
                continue;
            }

            if (anotherUserListensToSpecial(specialUser, userItr)) {
                return ("%s can't be "
                        + "deleted.").formatted(specialUser.getUsername());
            }
        }

        return "%s will remain in the system.".formatted(specialUser.getUsername());
    }

    /**
     * Removes other users links with the parameter user.
     *
     * @param user the user that will be deleted
     */
    public void removeNormalInteractions(final User user) {
        if (!user.getType().equals("user")) {
            return;
        }

        for (User userItr: users) {
            if (userItr.getUsername().equals(user.getUsername())) {
                continue;
            }

            // decreasing followers for other playlists
            Set<Playlist> playlistSet = new HashSet<>(userItr.getPlaylists());
            playlistSet.retainAll(user.getFollowedPlaylists());
            if (!playlistSet.isEmpty()) {
                for (Playlist playlistItr: playlistSet) {
                    playlistItr.decreaseFollowers();
                }
            }

            // deleting the normal user playlists from other users
            ArrayList<Playlist> modifyFollowedPlaylists = userItr.getFollowedPlaylists();
            playlistSet = new HashSet<>(userItr.getFollowedPlaylists());
            playlistSet.retainAll(user.getPlaylists());
            if (!playlistSet.isEmpty()) {
                for (Playlist playlistItr: playlistSet) {
                    modifyFollowedPlaylists.remove(playlistItr);
                }
            }

            userItr.setFollowedPlaylists(modifyFollowedPlaylists);
        }
    }

    /**
     * Removes a user from the system if possible.
     *
     * @return the message of the command validity
     */
    public String deleteUser(final User user) {
        String message = "";
        if (user.getType().equals("artist") || user.getType().equals("host")) {
            message = validUserDelete(user);
        }

        if (message.contains("deleted")) {
            return message;
        }

        ArrayList<Song> modifySongs = new ArrayList<>(songs);
        ArrayList<Album> modifyAlbums = new ArrayList<>(albums);
        ArrayList<Podcast> modifyPodcasts = new ArrayList<>(podcasts);

        if (user.getType().equals("artist")) {
            ArrayList<Song> artistSongs = new ArrayList<>();
            for (Album albumItr: albums) {
                if (!albumItr.getOwner().equals(user.getUsername())) {
                    continue;
                }

                artistSongs.addAll(albumItr.getSongs());
                for (Song albumSong: albumItr.getSongs()) {
                    modifySongs.removeIf(s -> s.getName().equals(albumSong.getName()));
                }
                modifyAlbums.remove(albumItr);
            }

            for (User userItr: users) {
                userItr.reverseArtistInteractions(artistSongs);
            }
        } else if (user.getType().equals("host")) {
            for (Podcast podcastItr: podcasts) {
                if (podcastItr.getOwner().equals(user.getUsername())) {
                    modifyPodcasts.remove(podcastItr);
                }
            }
        }

        songs = modifySongs;
        albums = modifyAlbums;
        podcasts = modifyPodcasts;

        if (user.getType().equals("user")) {
            if (user.getPlayer().getCurrentAudioFile() != null) {
                return "%s can't be deleted.".formatted(user.getUsername());
            }

            if (user.getPlayer().getSource() != null
                && user.getPlayer().getSource().getAudioCollection() != null) {
                return "%s can't be deleted.".formatted(user.getUsername());
            }

            if (anotherUserListensToNormal(user)) {
                return "%s can't be deleted.".formatted(user.getUsername());
            }
        }

        removeNormalInteractions(user);
        users.remove(user);
        return "%s was successfully deleted.".formatted(user.getUsername());
    }

    /**
     * Sets songs.
     *
     * @param songInputList the song input list
     */
    public void setSongs(final List<SongInput> songInputList) {
        songs = new ArrayList<>();
        for (SongInput songInput : songInputList) {
             songs.add(new Song(songInput.getName(), songInput.getDuration(), songInput.getAlbum(),
                       songInput.getTags(), songInput.getLyrics(), songInput.getGenre(),
                       songInput.getReleaseYear(), songInput.getArtist()));
        }
    }

    /**
     * Updates the admin list of songs.
     *
     * @param songList the new songList
     */
    public void updateSongs(final List<Song> songList) {
        songs = new ArrayList<>();
        songs.addAll(songList);
    }

    /**
     * Updates the admin list of podcasts.
     *
     * @param podcastList the new podcastList
     */
    public void updatePodcasts(final List<Podcast> podcastList) {
        podcasts = new ArrayList<>();
        podcasts.addAll(podcastList);
    }

    /**
     * Sets podcasts.
     *
     * @param podcastInputList the podcast input list
     */
    public void setPodcasts(final List<PodcastInput> podcastInputList) {
        podcasts = new ArrayList<>();
        for (PodcastInput podcastInput : podcastInputList) {
            List<Episode> episodes = new ArrayList<>();
            for (EpisodeInput episodeInput : podcastInput.getEpisodes()) {
                episodes.add(new Episode(episodeInput.getName(),
                                         episodeInput.getDuration(),
                                         episodeInput.getDescription()));
            }
            podcasts.add(new Podcast(podcastInput.getName(), podcastInput.getOwner(), episodes));
        }
    }

    /**
     * Gets songs.
     *
     * @return the songs
     */
    public List<Song> getSongs() {
        return new ArrayList<>(songs);
    }

    /**
     * Gets podcasts.
     *
     * @return the podcasts
     */
    public List<Podcast> getPodcasts() {
        return new ArrayList<>(podcasts);
    }

    /**
     * Gets playlists.
     *
     * @return the playlists
     */
    public List<Playlist> getPlaylists() {
        List<Playlist> playlists = new ArrayList<>();
        for (User user : users) {
            playlists.addAll(user.getPlaylists());
        }
        return playlists;
    }

    /**
     * Gets user.
     *
     * @param username the username
     * @return the user
     */
    public User getUser(final String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    /**
     * Update timestamp.
     *
     * @param newTimestamp the new timestamp
     */
    public void updateTimestamp(final int newTimestamp) {
        int elapsed = newTimestamp - timestamp;
        timestamp = newTimestamp;
        if (elapsed == 0) {
            return;
        }

        for (User user : users) {
            if (user.getType().equals("user")
                    && user.getConnection() == Enums.UserActivity.ONLINE) {
                user.simulateTime(elapsed);
            }
        }
    }

    /**
     * Gets top 5 songs.
     *
     * @return the top 5 songs
     */
    public List<String> getTop5Songs() {
        List<Song> sortedSongs = new ArrayList<>(songs);
        sortedSongs.sort(Comparator.comparingInt(Song::getLikes).reversed());
        List<String> topSongs = new ArrayList<>();
        int count = 0;
        for (Song song : sortedSongs) {
            if (count >= LIMIT) {
                break;
            }
            topSongs.add(song.getName());
            count++;
        }
        return topSongs;
    }

    /**
     * Gets top 5 playlists.
     *
     * @return the top 5 playlists
     */
    public List<String> getTop5Playlists() {
        List<Playlist> sortedPlaylists = new ArrayList<>(getPlaylists());
        sortedPlaylists.sort(Comparator.comparingInt(Playlist::getFollowers)
                .reversed()
                .thenComparing(Playlist::getTimestamp, Comparator.naturalOrder()));
        List<String> topPlaylists = new ArrayList<>();
        int count = 0;
        for (Playlist playlistItr : sortedPlaylists) {
            if (count >= LIMIT) {
                break;
            }
            topPlaylists.add(playlistItr.getName());
            count++;
        }
        return topPlaylists;
    }

    /**
     * Gets top 5 albums.
     *
     * @return the top 5 albums
     */
    public List<String> getTop5Albums() {
        List<Album> sortedAlbums = new ArrayList<>(albums);
        sortedAlbums.sort(Comparator.comparingInt(Album::getLikes)
                .reversed()
                .thenComparing(Album::getName, Comparator.naturalOrder()));
        List<String> topAlbums = new ArrayList<>();
        int count = 0;
        for (Album album : sortedAlbums) {
            if (count >= LIMIT) {
                break;
            }
            topAlbums.add(album.getName());
            count++;
        }
        return topAlbums;
    }

    /**
     * Gets top 5 artists.
     *
     * @return the top 5 artists
     */
    public List<String> getTop5Artists() {
        List<Artist> sortedArtists = new ArrayList<>();
        for (User userItr: users) {
            if (userItr.getType().equals("artist")) {
                sortedArtists.add((Artist) userItr);
            }
        }
        sortedArtists.sort(Comparator.comparingInt(Artist::getLikes)
                .reversed());
        List<String> topArtists = new ArrayList<>();
        int count = 0;
        for (Artist artistItr : sortedArtists) {
            if (count >= LIMIT) {
                break;
            }
            topArtists.add(artistItr.getUsername());
            count++;
        }
        return topArtists;
    }

    /**
     * Reset.
     */
    public void reset() {
        users = new ArrayList<>();
        songs = new ArrayList<>();
        podcasts = new ArrayList<>();
        albums = new ArrayList<>();
        timestamp = 0;
    }
}
