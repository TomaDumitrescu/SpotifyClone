package app.user;

import app.Admin;
import app.audio.Collections.Album;
import app.audio.Collections.AudioCollection;
import app.audio.Collections.Playlist;
import app.audio.Files.AudioFile;
import app.audio.Files.Song;
import app.player.PlayerSource;
import app.utils.output_formats.AlbumOutputFormat;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

@Getter
@Setter
public class Artist extends User {
    static class Event {
        private final String name;
        private final String description;
        private final String date;
        private static final int INF_YEAR = 1900;
        private static final int SUP_YEAR = 2023;
        private static final int SUP_MONTH = 12;
        private static final int SUP_FEBRUARY = 28;
        private static final int SUP_DAY = 31;
        private static final int FEBRUARY = 2;
        private static final int MAX_ZEROES = 3;

        /**
         * Instantiates an event
         *
         */
        Event(final String name, final String description,
                     final String date) {
            this.name = name;
            this.description = description;
            this.date = date;
        }

        /**
         * Checks if the data event is valid.
         *
         * @return true only if the data is valid
         */
        public boolean validDate() {
            String[] strNumbers = date.split("-");


            if (strNumbers[0].startsWith("0")) {
                strNumbers[0] = strNumbers[0].substring(1);
            }

            if (strNumbers[1].startsWith("0")) {
                strNumbers[1] = strNumbers[1].substring(1);
            }

            // only 3 zeroes can be subtracted so that it can be parsed
            for (int j = 1; j <= MAX_ZEROES; j++) {
                if (strNumbers[2].startsWith("0")) {
                    strNumbers[2] = strNumbers[2].substring(1);
                }
            }

            int day = Integer.parseInt(strNumbers[0]);
            int month = Integer.parseInt(strNumbers[1]);
            int year = Integer.parseInt(strNumbers[2]);

            if (day > SUP_DAY || month > SUP_MONTH || year < INF_YEAR
                    || year > SUP_YEAR) {
                return false;
            }

            return day <= SUP_FEBRUARY || month != FEBRUARY;
        }
    }

    static class Merch {
        private final String name;
        private final String description;
        private final Integer price;

        /**
         * Instantiates a merchandising product
         *
         */
        Merch(final String name, final String description,
                     final Integer price) {
            this.name = name;
            this.description = description;
            this.price = price;
        }

        /**
         * Checks if the price is positive.
         *
         * @return true only if the price is positive
         */
        public boolean validPrice() {
            return price >= 0;
        }
    }

    private ArrayList<Event> events;
    private ArrayList<Merch> merchObjects;

    /**
     * Instantiates a new Artist.
     *
     * @param username the username
     * @param age      the age
     * @param city     the city
     */
    public Artist(final String username, final int age, final String city) {
        super(username, age, city);
        events = new ArrayList<>();
        merchObjects = new ArrayList<>();
    }

    /**
     * Adds an album to the album list and checks the validity of the operations.
     *
     * @param album  the artist's album
     * @return the success message of the adding operation
     */
    public String addAlbum(final Album album) {
        List<Album> albums = Admin.getInstance().getAlbums();
        List<Song> songs = Admin.getInstance().getSongs();

        boolean uniqueSongs = true;
        ArrayList<Song> albumSongs = new ArrayList<>(album.getSongs());

        boolean uniqueAlbumName = true;
        for (Album albumItr: albums) {
            if (!albumItr.getOwner().equals(album.getOwner())) {
                continue;
            }
            if (albumItr.getName().equals(album.getName())) {
                uniqueAlbumName = false;
                break;
            }
        }

        if (!uniqueAlbumName) {
            return "%s has another album with the same name.".formatted(album.getOwner());
        }

        ArrayList<String> albumSongsNames = new ArrayList<>();
        for (Song songItr: albumSongs) {
            albumSongsNames.add(songItr.getName());
        }

        Set<String> nameSet = new HashSet<>(albumSongsNames);
        if (nameSet.size() < albumSongsNames.size()) {
            uniqueSongs = false;
        }

        if (!uniqueSongs) {
            return ("%s has the same song at least twice in this "
                    + "album.").formatted(album.getOwner());
        }

        songs.addAll(albumSongs);
        albums.add(album);
        Admin.getInstance().setAlbums(albums);
        Admin.getInstance().updateSongs(songs);

        return ("%s has added new album "
                + "successfully.").formatted(album.getOwner());
    }

    /**
     * Verifies if two song lists have common song names
     *
     * @param songs the first list
     * @param cmpSongs the second list
     * @return true if there are common names found
     */
    private boolean haveCommonSongs(final List<Song> songs, final List<Song> cmpSongs) {
        ArrayList<String> songNames = new ArrayList<>();
        for (Song songItr: songs) {
            songNames.add(songItr.getName());
        }

        ArrayList<String> cmpSongNames = new ArrayList<>();
        for (Song songItr: cmpSongs) {
            cmpSongNames.add(songItr.getName());
        }

        Set<String> songNamesSet = new HashSet<>(songNames);
        songNamesSet.retainAll(cmpSongNames);
        return !songNamesSet.isEmpty();
    }

    /**
     * Removes an album from the Admin album list.
     *
     * @param albumName the album name from the command details
     * @return the success message of the deleting operation
     */
    public String removeAlbum(final String albumName) {
        List<Album> allAlbums = Admin.getInstance().getAlbums();
        Album refAlbum = null;
        boolean existAlbum = false;

        for (Album albumItr: allAlbums) {
            if (albumItr.getName().equals(albumName)) {
                existAlbum = true;
                refAlbum = albumItr;
                break;
            }
        }

        if (!existAlbum) {
            return ("%s doesn't have an album with the "
                    + "given name.").formatted(this.getUsername());
        }

        List<User> users = Admin.getInstance().getAllUsers();
        for (User userItr: users) {
            PlayerSource playerSource = userItr.getPlayer().getSource();
            if (playerSource == null) {
                continue;
            }

            AudioCollection audioCollection = playerSource.getAudioCollection();
            if (audioCollection != null && audioCollection.getClass() == Playlist.class) {
                Playlist playlist = (Playlist) audioCollection;
                if (haveCommonSongs(refAlbum.getSongs(), playlist.getSongs())) {
                    return ("%s can't delete this "
                            + "album.").formatted(this.getUsername());
                }
            } else if (audioCollection != null
                       && audioCollection.getClass() == Album.class) {
                Album album = (Album) audioCollection;
                if (haveCommonSongs(refAlbum.getSongs(), album.getSongs())) {
                    return ("%s can't delete this "
                            + "album.").formatted(this.getUsername());
                }
            }

            AudioFile audioFile = playerSource.getAudioFile();
            if (audioFile == null) {
                continue;
            }
            for (Song songItr: refAlbum.getSongs()) {
                if (songItr.getName().equals(audioFile.getName())) {
                    return ("%s can't delete this "
                            + "album.").formatted(this.getUsername());
                }
            }
        }

        List<Song> modifySongs = new ArrayList<>(Admin.getInstance().getSongs());
        Set<Song> songSet = new HashSet<>(Admin.getInstance().getSongs());
        songSet.retainAll(refAlbum.getSongs());

        for (Song songItr: songSet) {
            modifySongs.remove(songItr);
        }

        Admin.getInstance().updateSongs(modifySongs);
        allAlbums.remove(refAlbum);
        Admin.getInstance().setAlbums(allAlbums);

        return "%s deleted the album successfully.".formatted(this.getUsername());
    }

    /**
     * Lists the albums of the current artist.
     *
     * @param albums the Admin list of albums
     * @return the success message of the listing operation
     */
    public ArrayList<AlbumOutputFormat> showAlbums(final List<Album> albums) {
        ArrayList<AlbumOutputFormat> results = new ArrayList<>();
        for (Album albumItr: albums) {
            if (albumItr.getOwner().equals(this.getUsername())) {
                AlbumOutputFormat outFormat = new AlbumOutputFormat();
                outFormat.setName(albumItr.getName());
                ArrayList<String> songNames = new ArrayList<>();

                for (Song songItr: albumItr.getSongs()) {
                    songNames.add(songItr.getName());
                }

                outFormat.setSongs(songNames);
                results.add(outFormat);
            }
        }

        return results;
    }

    /**
     * Adds an event to the current artist's list of events.
     *
     * @param name the event name
     * @param description the event name
     * @param date the event date
     * @return the success message of the adding operation
     */
    public String addEvent(final String name, final String description,
                           final String date) {

        Event event = new Event(name, description, date);
        for (Event eventItr: events) {
            if (eventItr.name.equalsIgnoreCase(event.name)) {
                return ("%s has another event with the same "
                        + "name.").formatted(this.getUsername());
            }
        }

        if (!event.validDate()) {
            return ("Event for %s does not have a "
                    + "valid date.").formatted(this.getUsername());
        }

        events.add(event);
        return ("%s has added new event "
                + "successfully.").formatted(this.getUsername());
    }

    /**
     * Removes an event from the current artist's list of events.
     *
     * @param eventName the name of the event that should be deleted
     * @return the success message of the removing operation
     */
    public String removeEvent(final String eventName) {
        ArrayList<Event> modifyEvents = new ArrayList<>(events);
        boolean existEvent = false;
        Iterator<Event> itr = modifyEvents.iterator();

        while (itr.hasNext()) {
            Event eventItr = itr.next();
            if (eventItr.name.equalsIgnoreCase(eventName)) {
                itr.remove();
                existEvent = true;
            }
        }

        if (!existEvent) {
            return ("%s doesn't have an event "
                    + "with the given name.").formatted(this.getUsername());
        }

        events = modifyEvents;
        return ("%s deleted the event successfully.").formatted(this.getUsername());
    }

    /**
     * Adds a merchandising article to the current artist's list of merchObjects.
     *
     * @param name the merch name
     * @param description the merch description
     * @param price the merch price
     * @return the success message of the adding operation
     */
    public String addMerch(final String name, final String description,
                           final Integer price) {
        Merch merch = new Merch(name, description, price);
        for (Merch merchItr: merchObjects) {
            if (merchItr.name.equalsIgnoreCase(merch.name)) {
                return ("%s has merchandise with "
                        + "the same name.").formatted(this.getUsername());
            }
        }

        if (!merch.validPrice()) {
            return "Price for merchandise can not be negative.";
        }

        merchObjects.add(merch);
        return ("%s has added new merchandise "
                + "successfully.").formatted(this.getUsername());
    }

    /**
     * Calculates the likes artist received for its products.
     *
     * @return the total likes over all artist's albums
     */
    public Integer getLikes() {
        Integer totalLikes = 0;
        List<Album> albums = Admin.getInstance().getAlbums();
        for (Album albumItr: albums) {
            if (albumItr.getOwner().equals(this.getUsername())) {
                totalLikes += albumItr.getLikes();
            }
        }

        return totalLikes;
    }

    /**
     * Creates the output format for an artist page, having
     * access to all events and merchandising products created by
     * the current artist.
     *
     * @return the format message
     */
    public String printArtistPage() {
        StringBuilder message = new StringBuilder();
        message.append("Albums:\n\t[");
        List<Album> albums = Admin.getInstance().getAlbums();
        List<Album> artistAlbums = new ArrayList<>();

        for (Album albumItr: albums) {
            if (albumItr.getOwner().equalsIgnoreCase(this.getUsername())) {
                artistAlbums.add(albumItr);
            }
        }

        int len = artistAlbums.size() - 1;
        for (int i = 0; i <= len; i++) {
            message.append(artistAlbums.get(i).getName());
            if (i != len) {
                message.append(", ");
            }
        }

        message.append("]\n\nMerch:\n\t[");
        len = merchObjects.size() - 1;
        for (int i = 0; i <= len; i++) {
            Merch currentMerch = merchObjects.get(i);
            message.append(currentMerch.name);
            message.append(" - ");
            message.append(currentMerch.price);
            message.append(":\n\t");
            message.append(currentMerch.description);
            if (i != len) {
                message.append(", ");
            }
        }

        message.append("]\n\nEvents:\n\t[");
        len = events.size() - 1;
        for (int i = 0; i <= len; i++) {
            Event currentEvent = events.get(i);
            message.append(currentEvent.name);
            message.append(" - ");
            message.append(currentEvent.date);
            message.append(":\n\t");
            message.append(currentEvent.description);
            if (i != len) {
                message.append(", ");
            }
        }
        message.append("]");

        return message.toString();
    }
}
