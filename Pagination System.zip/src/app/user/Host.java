package app.user;

import app.Admin;
import app.audio.Collections.AudioCollection;
import app.audio.Collections.Podcast;
import app.audio.Files.Episode;
import app.player.PlayerSource;
import app.utils.output_formats.PodcastOutputFormat;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Getter
@Setter
public class Host extends User {
    static class Announcement {
        private String name;
        private String description;

        /**
         * Instantiates an announcement.
         *
         * @param name the name of the announcement
         * @param description the information about the news
         */
        Announcement(final String name, final String description) {
            this.name = name;
            this.description = description;
        }
    }

    private ArrayList<Announcement> announcements;
    /**
     * Instantiates a new Host.
     *
     * @param username the username
     * @param age      the age
     * @param city     the city
     */
    public Host(final String username, final int age, final String city) {
        super(username, age, city);
        announcements = new ArrayList<>();
    }

    /**
     * Adds an announcement to the current host's list of announcements.
     *
     * @param name command announcement name
     * @param description command announcement description
     * @return the success message of the adding operation
     */
    public String addAnnouncement(final String name, final String description) {
        Announcement announcement = new Announcement(name, description);
        for (Announcement announcementItr: announcements) {
            if (announcementItr.name.equals(announcement.name)) {
                return ("%s has already added an announcement "
                        + "with this name.").formatted(this.getUsername());
            }
        }

        announcements.add(announcement);
        return ("%s has successfully added new "
                + "announcement.").formatted(this.getUsername());
    }

    /**
     * Removes an announcement created by the actual host.
     *
     * @param announcementName the announcement name
     * @return the success message of the removing operation
     */
    public String removeAnnouncement(final String announcementName) {
        ArrayList<Announcement> modifyAnnouncements = new ArrayList<>(announcements);
        boolean existAnnouncement = false;

        Iterator<Announcement> itr = modifyAnnouncements.iterator();

        while (itr.hasNext()) {
            Announcement announcementItr = itr.next();
            if (announcementItr.name.equalsIgnoreCase(announcementName)) {
                itr.remove();
                existAnnouncement = true;
            }
        }

        if (!existAnnouncement) {
            return ("%s has no announcement with "
                    + "the given name.").formatted(this.getUsername());
        }

        announcements = modifyAnnouncements;
        return ("%s has successfully deleted the "
                + "announcement.").formatted(this.getUsername());
    }

    /**
     * Lists the podcasts of the current host.
     *
     * @param podcasts the Admin list of podcasts
     * @return the success message of the listing operation
     */
    public ArrayList<PodcastOutputFormat> showPodcasts(final List<Podcast> podcasts) {
        ArrayList<PodcastOutputFormat> results = new ArrayList<>();
        for (Podcast podcastItr: podcasts) {
            if (podcastItr.getOwner().equals(this.getUsername())) {
                PodcastOutputFormat outFormat = new PodcastOutputFormat();
                outFormat.setName(podcastItr.getName());

                ArrayList<String> podcastEpisodeNames = new ArrayList<>();
                for (Episode episodeItr: podcastItr.getEpisodes()) {
                    podcastEpisodeNames.add(episodeItr.getName());
                }

                outFormat.setEpisodes(podcastEpisodeNames);
                results.add(outFormat);
            }
        }

        return results;
    }

    /**
     * Adds a podcast to the podcasts list and checks the validity of the operations.
     *
     * @param podcast the host's podcast
     * @return the success message of the adding operation
     */
    public String addPodcast(final Podcast podcast) {
        List<Podcast> podcasts = Admin.getInstance().getPodcasts();

        boolean uniquePodcastName = true;
        for (Podcast podcastItr: podcasts) {
            if (!podcastItr.getOwner().equals(podcast.getOwner())) {
                continue;
            }

            if (podcastItr.getName().equals(podcast.getName())) {
                uniquePodcastName = false;
                break;
            }
        }

        if (!uniquePodcastName) {
            return "%s has another podcast with the same name.".formatted(podcast.getOwner());
        }

        boolean uniqueEpisodes = true;
        for (Podcast podcastItr: podcasts) {
            if (!podcastItr.getOwner().equals(podcast.getOwner())) {
                continue;
            }

            for (Episode episodeItr: podcastItr.getEpisodes()) {
                for (Episode eNew: podcast.getEpisodes()) {
                    if (episodeItr.getName().equalsIgnoreCase(eNew.getName())) {
                        uniqueEpisodes = false;
                        break;
                    }
                }
            }
        }

        if (!uniqueEpisodes) {
            return "%s has the same episode in this podcast.".formatted(podcast.getOwner());
        }

        podcasts.add(podcast);
        Admin.getInstance().updatePodcasts(podcasts);

        return ("%s has added new podcast "
                + "successfully.").formatted(podcast.getOwner());
    }

    /**
     * Removes a podcast from the Admin podcast list.
     *
     * @param podcastName the podcast name from the command details
     * @return the success message of the removing operation
     */
    public String removePodcast(final String podcastName) {
        List<Podcast> allPodcasts = Admin.getInstance().getPodcasts();
        Podcast refPodcast = null;
        boolean existPodcast = false;

        for (Podcast podcastItr: allPodcasts) {
            if (podcastItr.getName().equals(podcastName)) {
                existPodcast = true;
                refPodcast = podcastItr;
                break;
            }
        }

        if (!existPodcast) {
            return ("%s doesn't have a podcast with the "
                    + "given name.").formatted(this.getUsername());
        }

        List<User> users = Admin.getInstance().getAllUsers();
        for (User userItr: users) {
            PlayerSource playerSource = userItr.getPlayer().getSource();
            if (playerSource == null) {
                continue;
            }

            AudioCollection audioCollection = playerSource.getAudioCollection();
            if (audioCollection == null) {
                continue;
            }

            if (audioCollection.getClass() == Podcast.class) {
                Podcast cmpPodcast = (Podcast) audioCollection;
                if (cmpPodcast.getName().equals(podcastName)) {
                    return ("%s can't delete this "
                            + "podcast.").formatted(this.getUsername());
                }
            }
        }

        allPodcasts.remove(refPodcast);
        Admin.getInstance().updatePodcasts(allPodcasts);
        return "%s deleted the podcast successfully.".formatted(this.getUsername());
    }

    /**
     * Creates the output format for a host page, having
     * access to all announcements and podcasts created by
     * the current host.
     *
     * @return the format that will go to command message
     */
    public String printHostPage() {
        StringBuilder message = new StringBuilder();
        message.append("Podcasts:\n\t[");
        List<Podcast> allPodcasts = Admin.getInstance().getPodcasts();
        List<Podcast> podcasts = new ArrayList<>();

        for (Podcast podcastItr: allPodcasts) {
            if (podcastItr.getOwner().equals(this.getUsername())) {
                podcasts.add(podcastItr);
            }
        }

        int len = podcasts.size() - 1, numEpisodes;
        for (int i = 0; i <= len; i++) {
            message.append(podcasts.get(i).getName());
            message.append(":\n\t[");
            List<Episode> episodes = podcasts.get(i).getEpisodes();
            numEpisodes = episodes.size() - 1;

            for (int j = 0; j <= numEpisodes; j++) {
                message.append(episodes.get(j).getName());
                message.append(" - ");
                message.append(episodes.get(j).getDescription());
                if (j != numEpisodes) {
                    message.append(", ");
                }
            }

            message.append("]\n");
            if (i != len) {
                message.append(", ");
            }
        }

        message.append("]\n\nAnnouncements:\n\t[");
        len = announcements.size() - 1;
        for (int i = 0; i <= len; i++) {
            message.append(announcements.get(i).name);
            message.append(":\n\t");
            message.append(announcements.get(i).description);
            if (i != len) {
                message.append("\n, ");
            }
        }
        message.append("\n]");
        return message.toString();
    }
}
