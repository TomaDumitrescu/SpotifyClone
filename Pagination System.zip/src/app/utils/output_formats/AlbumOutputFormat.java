package app.utils.output_formats;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AlbumOutputFormat {
    private String name;
    private ArrayList<String> songs;

    public AlbumOutputFormat() {
    }
}
