package app.utils.output_formats;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PodcastOutputFormat {
    private String name;
    private ArrayList<String> episodes;

    public PodcastOutputFormat() {
    }
}
