package app;

import app.audio.Collections.Album;
import app.audio.Collections.PlaylistOutput;
import app.audio.Collections.Podcast;
import app.audio.Files.Episode;
import app.player.PlayerStats;
import app.searchBar.Filters;
import app.user.Artist;
import app.user.Host;
import app.user.User;
import app.utils.Enums;
import app.utils.output_formats.AlbumOutputFormat;
import app.utils.output_formats.PodcastOutputFormat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import fileio.input.CommandInput;
import fileio.input.EpisodeInput;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Command runner.
 */
public final class CommandRunner {
    /**
     * The Object mapper.
     */
    private static ObjectMapper objectMapper = new ObjectMapper();

    private CommandRunner() {
    }

    /**
     * Search object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode search(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());
        Filters filters = new Filters(commandInput.getFilters());
        String type = commandInput.getType();
        ArrayList<String> results = new ArrayList<>();

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            // extended functionality for special users searching
            results = user.search(filters, type);
            message = "Search returned " + results.size() + " results";
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);
        objectNode.put("results", objectMapper.valueToTree(results));

        return objectNode;
    }

    /**
     * Select object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode select(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            // extended functionality for selecting artists or hosts
            message = user.select(commandInput.getItemNumber());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Load object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode load(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            // load objects can be songs, playlists, albums or podcasts
            message = user.load();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Play pause object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode playPause(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.playPause();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Repeat object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode repeat(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.repeat();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Shuffle object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode shuffle(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());
        Integer seed = commandInput.getSeed();

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.shuffle(seed);
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Forward object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode forward(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.forward();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Backward object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode backward(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;

        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.backward();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Like object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode like(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.like();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Next object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode next(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.next();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Prev object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode prev(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.prev();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Create playlist object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode createPlaylist(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.createPlaylist(commandInput.getPlaylistName(),
                                          commandInput.getTimestamp());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Add remove in playlist object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addRemoveInPlaylist(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.addRemoveInPlaylist(commandInput.getPlaylistId());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Switch visibility object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode switchVisibility(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.switchPlaylistVisibility(commandInput.getPlaylistId());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Show playlists object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode showPlaylists(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        ArrayList<PlaylistOutput> playlists = new ArrayList<>();
        if (user != null) {
            playlists = user.showPlaylists();
        }

        ObjectNode objectNode;
        objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(playlists));

        return objectNode;
    }

    /**
     * Follow object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode follow(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "%s does not exist".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(commandInput.getUsername());
        } else {
            message = user.follow();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Status object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode status(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        PlayerStats stats = null;
        if (user != null) {
            stats = user.getPlayerStats();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("stats", objectMapper.valueToTree(stats));

        return objectNode;
    }

    /**
     * Show liked songs object node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode showLikedSongs(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        ArrayList<String> songs = new ArrayList<>();
        if (user != null) {
            songs = user.showPreferredSongs();
        }

        var objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(songs));

        return objectNode;
    }

    /**
     * Gets preferred genre.
     *
     * @param commandInput the command input
     * @return the preferred genre
     */
    public static ObjectNode getPreferredGenre(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String preferredGenre = "";
        if (user != null) {
            preferredGenre = user.getPreferredGenre();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", preferredGenre);

        return objectNode;
    }

    /**
     * Gets top 5 songs.
     *
     * @param commandInput the command input
     * @return the top 5 songs
     */
    public static ObjectNode getTop5Songs(final CommandInput commandInput) {
        List<String> songs = Admin.getInstance().getTop5Songs();

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(songs));

        return objectNode;
    }

    /**
     * Gets top 5 playlists.
     *
     * @param commandInput the command input
     * @return the top 5 playlists
     */
    public static ObjectNode getTop5Playlists(final CommandInput commandInput) {
        List<String> playlists = Admin.getInstance().getTop5Playlists();

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(playlists));

        return objectNode;
    }

    /**
     * Switch user connection node.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode switchConnectionStatus(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else {
            if (!user.getType().equals("user")) {
                message = "%s is not a normal user.".formatted(commandInput.getUsername());
            } else {
                user.switchConnectionStatus();
                message = ("%s has changed status "
                            + "successfully.").formatted(commandInput.getUsername());
            }
        }
        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Lists the online users by name.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode getOnlineUsers(final CommandInput commandInput) {
        ArrayList<String> onlineUsers = Admin.getInstance().getOnlineUsers();

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(onlineUsers));

        return objectNode;
    }

    /**
     * Adds a user to the platform if the operation is valid.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addUser(final CommandInput commandInput) {
        String message = Admin.getInstance().addUser(commandInput.getUsername(),
                commandInput.getAge(), commandInput.getCity(), commandInput.getType());

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Adds an album and its songs in the library.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addAlbum(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("artist")) {
            message = "%s is not an artist.".formatted(commandInput.getUsername());
        } else {
            Album album = new Album(commandInput.getName(), commandInput.getUsername(),
                                    commandInput.getSongs(), commandInput.getDescription(),
                                    commandInput.getReleaseYear());

            // cast possible because type is guaranteed to be artist
            message = ((Artist) user).addAlbum(album);
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Lists the albums of an artist.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode showAlbums(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());
        List<Album> albums = Admin.getInstance().getAlbums();

        ArrayList<AlbumOutputFormat> results = new ArrayList<>();
        if (user != null) {
            results = ((Artist) user).showAlbums(albums);
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());

        if (user != null) {
            objectNode.put("result", objectMapper.valueToTree(results));
        }

        return objectNode;
    }

    /**
     * Saves the ASCII format of the page in the field message.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode printCurrentPage(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(user.getUsername());
        } else {
            message = user.printCurrentPage();
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("user", commandInput.getUsername());
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Adds an event to the artist's list of events.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addEvent(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("artist")) {
            message = "%s is not an artist.".formatted(commandInput.getUsername());
        } else {
            message = ((Artist) user).addEvent(commandInput.getName(),
                                               commandInput.getDescription(),
                                               commandInput.getDate());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Adds a merchandising object to the artist's merch.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addMerch(final CommandInput commandInput) {
        var user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("artist")) {
            message = "The username %s is not an artist.".formatted(commandInput.getUsername());
        } else {
            message = ((Artist) user).addMerch(commandInput.getName(),
                                               commandInput.getDescription(),
                                               commandInput.getPrice());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Lists all users from the system in normal, artist, host.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode getAllUsers(final CommandInput commandInput) {
        ArrayList<User> users = Admin.getInstance().getAllUsers();
        ArrayList<String> usernames = new ArrayList<>();

        for (User userItr: users) {
            if (userItr.getType().equals("user")) {
                usernames.add(userItr.getUsername());
            }
        }

        for (User userItr: users) {
            if (userItr.getType().equals("artist")) {
                usernames.add(userItr.getUsername());
            }
        }

        for (User userItr: users) {
            if (userItr.getType().equals("host")) {
                usernames.add(userItr.getUsername());
            }
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(usernames));

        return objectNode;
    }

    /**
     * Deletes a user if others do not interact with it.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode deleteUser(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else {
            message = Admin.getInstance().deleteUser(user);
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Adds an announcement in the host's list.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addAnnouncement(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("host")) {
            message = "%s is not a host.".formatted(commandInput.getUsername());
        } else {
            message = ((Host) user).addAnnouncement(commandInput.getName(),
                                                    commandInput.getDescription());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Removes an announcement from the host's list.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode removeAnnouncement(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("host")) {
            message = "%s is not a host.".formatted(commandInput.getUsername());
        } else {
            message = ((Host) user).removeAnnouncement(commandInput.getName());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Lists the podcasts of a host.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode showPodcasts(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        List<Podcast> podcasts = Admin.getInstance().getPodcasts();
        ArrayList<PodcastOutputFormat> results = new ArrayList<>();
        if (user != null) {
            results = ((Host) user).showPodcasts(podcasts);
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(results));

        return objectNode;
    }

    /**
     * Adds a podcast to the host's list.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode addPodcast(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = ("The username %s doesn't "
                        + "exist.").formatted(commandInput.getUsername());
        } else if (!user.getType().equals("host")) {
            message = ("%s is not a host.").formatted(commandInput.getUsername());
        } else {
            ArrayList<Episode> episodes = new ArrayList<>();
            ArrayList<EpisodeInput> inputEpisodes = commandInput.getEpisodes();

            for (EpisodeInput episodeItr: inputEpisodes) {
                Episode convertEp = new Episode(episodeItr.getName(), episodeItr.getDuration(),
                                                episodeItr.getDescription());
                episodes.add(convertEp);
            }

            Podcast podcast = new Podcast(commandInput.getName(), commandInput.getUsername(),
                                          episodes);

            message = ((Host) user).addPodcast(podcast);
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Changes the page of the specific user.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode changePage(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("user")) {
            message = "%s is is not a normal user.".formatted(user.getUsername());
        } else if (user.getConnection() == Enums.UserActivity.OFFLINE) {
            message = "%s is offline.".formatted(user.getUsername());
        } else {
            message = user.changePage(commandInput.getNextPage());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("user", commandInput.getUsername());
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Removes an album and its songs from the dynamic musical library.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode removeAlbum(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("artist")) {
            message = "%s is not an artist.".formatted(commandInput.getUsername());
        } else {
            message = ((Artist) user).removeAlbum(commandInput.getName());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Removes an event from the artist's list of events.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode removeEvent(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("artist")) {
            message = "%s is not an artist.".formatted(commandInput.getUsername());
        } else {
            message = ((Artist) user).removeEvent(commandInput.getName());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }

    /**
     * Gets top 5 albums.
     *
     * @param commandInput the command input
     * @return the top 5 albums
     */
    public static ObjectNode getTop5Albums(final CommandInput commandInput) {
        List<String> songs = Admin.getInstance().getTop5Albums();

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(songs));

        return objectNode;
    }

    /**
     * Gets top 5 artists.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode getTop5Artists(final CommandInput commandInput) {
        List<String> songs = Admin.getInstance().getTop5Artists();

        ObjectNode objectNode = objectMapper.createObjectNode();
        objectNode.put("command", commandInput.getCommand());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("result", objectMapper.valueToTree(songs));

        return objectNode;
    }

    /**
     * Removes a podcast from the list.
     *
     * @param commandInput the command input
     * @return the object node
     */
    public static ObjectNode removePodcast(final CommandInput commandInput) {
        User user = Admin.getInstance().getUser(commandInput.getUsername());

        String message;
        if (user == null) {
            message = "The username %s doesn't exist.".formatted(commandInput.getUsername());
        } else if (!user.getType().equals("host")) {
            message = "%s is not a host.".formatted(commandInput.getUsername());
        } else {
            message = ((Host) user).removePodcast(commandInput.getName());
        }

        ObjectNode objectNode = objectMapper.createObjectNode();

        objectNode.put("command", commandInput.getCommand());
        objectNode.put("user", commandInput.getUsername());
        objectNode.put("timestamp", commandInput.getTimestamp());
        objectNode.put("message", message);

        return objectNode;
    }
}
