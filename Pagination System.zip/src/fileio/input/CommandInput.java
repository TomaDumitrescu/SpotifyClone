package fileio.input;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
public final class CommandInput {
    private String command;
    private String username;
    private Integer timestamp;
    private String type;
    private FiltersInput filters;
    private Integer itemNumber;
    private Integer repeatMode;
    private Integer playlistId;
    private String playlistName;
    private Integer seed;
    private Integer age;
    private String city;
    private String name;
    private String description;
    private ArrayList<EpisodeInput> episodes;
    private Integer price;
    private String date;
    private Integer releaseYear;
    private ArrayList<SongInput> songs;
    private String nextPage;

    public CommandInput() {
    }

    @Override
    public String toString() {
        return "CommandInput{"
                + "command='" + command + '\''
                + ", username='" + username + '\''
                + ", timestamp=" + timestamp
                + ", type='" + type + '\''
                + ", filters=" + filters
                + ", itemNumber=" + itemNumber
                + ", repeatMode=" + repeatMode
                + ", playlistId=" + playlistId
                + ", playlistName='" + playlistName + '\''
                + ", seed=" + seed
                + '}';
    }
}
